import pygame
import sys
import random as r
pygame.init()

white=(255,255,255)
black=(0,0,0)
red=(255,0,0)
font = pygame.font.SysFont('Comic Sans MS', 75)
position=(400,100)
font2 = pygame.font.SysFont('Comic Sans MS', 25)

gallow=pygame.image.load('hangman_1.png')
gallowRect=gallow.get_rect(center=(500,300))
image1=pygame.image.load('hangman_2.png')
image1Rect=image1.get_rect(center=(500,300))
image2=pygame.image.load('hangman_3.png')
image2Rect=image2.get_rect(center=(500,300))
image3=pygame.image.load('hangman_4.png')
image3Rect=image3.get_rect(center=(500,300))
image4=pygame.image.load('hangman_5.png')
image4Rect=image4.get_rect(center=(500,300))
image5=pygame.image.load('hangman_6.png')
image5Rect=image5.get_rect(center=(500,300))
loseImage=pygame.image.load('hangman_full.png')
loseImageRect=loseImage.get_rect(center=(500,300))
hangman=[image1,image2,image3, image4, image5, loseImage]
hangmanRect=[image1Rect, image2Rect, image3Rect, image4Rect, image5Rect, loseImageRect]
mainScreen= pygame.display.set_mode((800,600))
mainScreen.fill(white)

def displayText(screen, text, font, color, position):
    textSurface= font.render(text,True, color)
    textRect= textSurface.get_rect(center=position)
    screen.blit(textSurface, textRect)

with open('wordList.txt','r') as file:
    lines = file.readlines()
word=(r.choice(lines)).strip()
letters=[]
for l in word:
    letters.append(l)
blank='___  '*len(letters)
correctWord = ['___  '] * len(letters)
incorrectLetters =[]

def allIndex(s,cha):
   return [i for i, c in enumerate(s) if c == cha]



x=200
y=300
dx=2
dy=1
count=0

gameOver= False
mainScreen.fill(white)
mainScreen.blit(gallow,gallowRect)
displayText(mainScreen,blank,font2,black,(400,500))

while True:
    displayText(mainScreen,'HANGMAN',font,black,position)
   
    if gameOver:
        pygame.display.flip()
        continue

    displayText(mainScreen, 'Incorrect Letters: ' + ', '.join(incorrectLetters), font2, red, (150,300))

    pygame.display.flip()
    x+=dx
    y+=dy

    if x > 800 or x < 0:
        dx = -dx
    if y > 600 or y < 0:
        dy = -dy
    
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            pygame.quit()
            sys.exit()
        elif event.type==pygame.KEYDOWN:
            letter=pygame.key.name(event.key)
            if letter in letters:
                I=allIndex(word,letter)
                for i in I:
                    correctWord[i]=letter
                displayText(mainScreen,' '.join(correctWord), font2, black,(400,500))
                pygame.display.flip()
                if '___  ' not in correctWord:
                    mainScreen.fill(white)
                    displayText(mainScreen,'YOU WON!',font,black,(400,300))
                    pygame.display.flip()
                    gameOver=True
            else:
                incorrectLetters.append(letter)
                mainScreen.blit(hangman[count],hangmanRect[count])
                pygame.display.flip()
                count+=1
                if count>= len(hangman):
                    mainScreen.fill(white)
                    displayText(mainScreen,'YOU LOST!',font,black,(400,300))
                    displayText(mainScreen,f'The word was {word}',font2,black,(400,350))
                    pygame.display.flip()